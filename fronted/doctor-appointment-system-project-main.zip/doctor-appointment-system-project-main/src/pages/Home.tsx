import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { patientApi } from '../api/patient';
import type { Doctor } from '../types';
import { useAuth } from '../auth/AuthContext';
import {
  CalendarCheck,
  Clock,
  ShieldCheck,
  Stethoscope,
  ChevronRight,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';
import { Loading } from '../components/Loading';

export const Home: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    patientApi
      .getDoctors()
      .then((data) => setDoctors(data || []))
      .catch(() => setDoctors([]))
      .finally(() => setLoading(false));
  }, []);

  const getDashboardPath = () => {
    if (!user) return '/login';
    if (user.role === 'admin') return '/admin/dashboard';
    if (user.role === 'doctor') return '/doctor/dashboard';
    return '/patient/dashboard';
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Clinic Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-900 via-teal-800 to-slate-900 text-white py-16 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />
        <div className="relative max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-400/30 text-xs font-semibold mb-6">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            Nowshera Family Clinic — Patient & Appointment System
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-6 leading-tight">
            Centralized Healthcare & Direct Doctor Scheduling
          </h1>
          <p className="text-base sm:text-lg text-teal-100 max-w-2xl mx-auto mb-10 leading-relaxed">
            Book verified 30-minute consultation slots with our licensed specialists. No double bookings, no unorganized schedules, and complete privacy for your medical visits.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            {isAuthenticated ? (
              <Link
                to={getDashboardPath()}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold rounded-xl shadow-lg transition-all"
              >
                Enter {user?.role.toUpperCase()} Dashboard
                <ChevronRight className="w-5 h-5" />
              </Link>
            ) : (
              <>
                <Link
                  to="/signup"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold rounded-xl shadow-lg transition-all"
                >
                  Book an Appointment (Register)
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl border border-white/20 transition-all"
                >
                  Sign In to Account
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Core Principles */}
      <section className="py-12 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 border border-teal-100">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-1">Guaranteed 30-Min Slots</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Real-time slots generated directly from each doctor's weekly working schedule.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
                <CalendarCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-1">Zero Double Bookings</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Doctor availability and leave calendars strictly prevent slot conflicts and patient clashes.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-100">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-1">Private Clinical Notes</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Visit notes are strictly restricted to the patient and attending doctor.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Doctors Section */}
      <section className="py-14 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex-1">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Our Medical Specialists</h2>
            <p className="text-sm text-slate-600 mt-1">
              Active clinicians available for scheduled appointments at Nowshera Family Clinic.
            </p>
          </div>
          <Link
            to={isAuthenticated && user?.role === 'patient' ? '/patient/book' : '/login'}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-teal-700 hover:text-teal-800"
          >
            Book with a Doctor <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <Loading message="Loading registered clinicians..." />
        ) : doctors.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500">
            <Stethoscope className="w-10 h-10 mx-auto text-slate-400 mb-3" />
            <p className="font-medium text-slate-700">No active doctors found at the moment.</p>
            <p className="text-xs text-slate-500 mt-1">Please check back shortly or consult clinic administration.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {doctors.map((doc) => (
              <div
                key={doc.id}
                className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:border-teal-300 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-lg">
                      {doc.full_name.charAt(0) || 'D'}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">{doc.full_name}</h4>
                      <span className="inline-block text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
                        {doc.specialty}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs text-slate-600 pt-2 border-t border-slate-100 mb-6">
                    {doc.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{doc.phone}</span>
                      </div>
                    )}
                    {doc.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span>{doc.email}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700 font-medium">Accepting New Patients</span>
                    </div>
                  </div>
                </div>

                <Link
                  to={isAuthenticated && user?.role === 'patient' ? `/patient/book?doctor=${doc.id}` : '/login'}
                  className="w-full py-2.5 px-4 rounded-lg bg-teal-50 hover:bg-teal-600 text-teal-700 hover:text-white font-medium text-xs text-center transition flex items-center justify-center gap-2 border border-teal-200 hover:border-teal-600"
                >
                  <CalendarCheck className="w-4 h-4" />
                  Select & View Slots
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Footer Info */}
      <footer className="bg-white border-t border-slate-200 py-8 px-4 sm:px-6 lg:px-8 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-slate-400" />
            <span>Nowshera Family Clinic, Main GT Road, Nowshera</span>
          </div>
          <div>
            <span>Official Patient & Staff Portal © {new Date().getFullYear()}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
