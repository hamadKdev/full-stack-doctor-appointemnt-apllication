import React, { useEffect, useState } from 'react';
import { adminApi } from '../../api/admin';
import type { User } from '../../types';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { Users, ShieldCheck, Mail, Phone, Calendar, Search } from 'lucide-react';

export const AdminPatients: React.FC = () => {
  const [patients, setPatients] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchPatients = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminApi.getPatients();
      setPatients(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve patient directory.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const filteredPatients = patients.filter((p) => {
    const term = searchTerm.toLowerCase();
    return (
      p.full_name.toLowerCase().includes(term) ||
      p.email.toLowerCase().includes(term) ||
      (p.phone && p.phone.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Patient Directory & Registry
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Registered patient demographic and contact records across Nowshera Family Clinic.
        </p>
      </div>

      {/* Privacy Notice Card */}
      <div className="p-4 rounded-xl bg-purple-50 border border-purple-200/80 text-xs text-purple-900 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-bold">HIPAA / Clinical Confidentiality Enforced:</span>
          <p className="mt-0.5">
            Administrators have operational access to contact records for billing and communications. Private clinical consultation notes, symptom logs, and specialist diagnoses are strictly encrypted and invisible on administrative endpoints.
          </p>
        </div>
      </div>

      {error && <ErrorMessage message={error} onRetry={fetchPatients} onDismiss={() => setError(null)} />}

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter by patient name, email, or phone..."
            className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-purple-500"
          />
        </div>
        <span className="text-xs text-slate-500 font-medium">
          {filteredPatients.length} patient{filteredPatients.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Table */}
      {loading ? (
        <Loading message="Fetching registered patient registry..." />
      ) : filteredPatients.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No Patients Match</h3>
          <p className="text-xs text-slate-500 mt-1">
            No patient records matched the search keyword.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4 font-semibold">Patient Name</th>
                  <th className="py-3 px-4 font-semibold">Email Address</th>
                  <th className="py-3 px-4 font-semibold">Contact Phone</th>
                  <th className="py-3 px-4 font-semibold">Account Role</th>
                  <th className="py-3 px-4 font-semibold">Registration Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPatients.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">
                          {p.full_name?.charAt(0) || 'P'}
                        </div>
                        <span>{p.full_name}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-medium">{p.email}</td>
                    <td className="py-3.5 px-4 text-slate-600">{p.phone || '—'}</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 uppercase">
                        {p.role}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {p.created_at ? new Date(p.created_at).toLocaleDateString() : 'Active'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
