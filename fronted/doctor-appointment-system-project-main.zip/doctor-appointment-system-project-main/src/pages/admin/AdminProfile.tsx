import React, { useState } from 'react';
import { useAuth } from '../../auth/AuthContext';
import { Shield, Mail, Activity, Server, CheckCircle2, Lock } from 'lucide-react';
import { API_BASE_URL } from '../../api/api';

export const AdminProfile: React.FC = () => {
  const { user } = useAuth();
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(API_BASE_URL);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Administrator Profile & System Settings
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Operational permissions, backend FastAPI connectivity, and security configuration.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-2xl shadow-inner">
            <Shield className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">{user?.full_name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-800 border border-purple-200">
                Clinic Administrator
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Nowshera Family Clinic Systems Officer</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Mail className="w-3.5 h-3.5" /> Admin Email
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.email}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Lock className="w-3.5 h-3.5" /> Authorization Scope
            </div>
            <p className="text-sm font-semibold text-purple-700">Full Administrative RBAC</p>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-100 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-2">
            <Server className="w-4 h-4 text-teal-600" /> Connected Backend Endpoint
          </h3>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="font-mono text-slate-700 truncate">{API_BASE_URL}</div>
            <button
              type="button"
              onClick={handleCopyUrl}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg font-medium text-slate-700 shrink-0 transition"
            >
              {copiedUrl ? 'Copied' : 'Copy Endpoint URL'}
            </button>
          </div>

          <div className="p-4 rounded-xl bg-purple-50 border border-purple-200 text-xs text-purple-900 flex items-start gap-3">
            <Activity className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-bold">Clinic Privacy & Data Governance:</span>
              <p className="mt-0.5">
                The administrative dashboard enforces strict separation of operational management from confidential clinical records. Doctor availability, leave days, and patient schedules are maintained while clinical visit notes remain strictly private.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
