import React, { useEffect, useState } from 'react';
import { adminApi } from '../../api/admin';
import type { Doctor, CreateDoctorResponse } from '../../types';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import {
  Stethoscope,
  Plus,
  UserX,
  Phone,
  Mail,
  Copy,
  Check,
  CheckCircle2,
  X,
  Shield,
  AlertCircle,
} from 'lucide-react';

export const AdminDoctors: React.FC = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Add doctor modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    specialty: '',
  });
  const [isAdding, setIsAdding] = useState(false);
  const [createdDoctorResult, setCreatedDoctorResult] = useState<CreateDoctorResponse | null>(null);
  const [copiedPassword, setCopiedPassword] = useState(false);

  // Deactivate modal
  const [deactivateTarget, setDeactivateTarget] = useState<Doctor | null>(null);
  const [isDeactivating, setIsDeactivating] = useState(false);

  const fetchDoctors = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await adminApi.getDoctors();
      setDoctors(list || []);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch doctor roster.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const handleAddDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.full_name || !formData.email || !formData.specialty) {
      setError('Please provide all mandatory fields.');
      return;
    }

    setIsAdding(true);
    setError(null);
    try {
      const res = await adminApi.createDoctor({
        full_name: formData.full_name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        specialty: formData.specialty.trim(),
      });

      setCreatedDoctorResult(res);
      setFormData({ full_name: '', email: '', phone: '', specialty: '' });
      await fetchDoctors();
    } catch (err: any) {
      setError(err.message || 'Failed to create physician profile.');
    } finally {
      setIsAdding(false);
    }
  };

  const handleConfirmDeactivate = async () => {
    if (!deactivateTarget) return;
    setIsDeactivating(true);
    setError(null);
    try {
      const res = await adminApi.deactivateDoctor(deactivateTarget.id);
      setSuccessMsg(res.message || `Physician ${deactivateTarget.full_name} deactivated.`);
      setDeactivateTarget(null);
      await fetchDoctors();
    } catch (err: any) {
      setError(err.message || 'Failed to deactivate physician.');
    } finally {
      setIsDeactivating(false);
    }
  };

  const handleCopyPassword = (pwd: string) => {
    navigator.clipboard.writeText(pwd);
    setCopiedPassword(true);
    setTimeout(() => setCopiedPassword(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Physician & Specialist Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Register new clinic doctors, provision temporary passwords, and control clinical active status.
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            setIsAddModalOpen(true);
            setCreatedDoctorResult(null);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl shadow-xs transition"
        >
          <Plus className="w-4 h-4" /> Add New Doctor
        </button>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {/* Doctors Cards */}
      {loading ? (
        <Loading message="Loading physician directory..." />
      ) : doctors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <Stethoscope className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No Doctors Found</h3>
          <p className="text-xs text-slate-500 mt-1">Click above to add the clinic's first physician.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {doctors.map((doc) => {
            const isActive = doc.is_active !== false;

            return (
              <div
                key={doc.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between hover:border-slate-300 transition"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-base">
                        {doc.full_name?.charAt(0) || 'D'}
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-900">{doc.full_name}</h3>
                        <span className="text-[11px] font-semibold text-purple-700 block">
                          {doc.specialty}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-500 border-slate-200'
                      }`}
                    >
                      {isActive ? 'Active' : 'Deactivated'}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 pt-3 border-t border-slate-100 mb-6">
                    {doc.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{doc.phone}</span>
                      </div>
                    )}
                    {doc.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span className="truncate">{doc.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-2">
                  {isActive ? (
                    <button
                      type="button"
                      onClick={() => setDeactivateTarget(doc)}
                      className="w-full py-2 px-3 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 font-semibold text-xs transition flex items-center justify-center gap-1.5"
                    >
                      <UserX className="w-3.5 h-3.5" /> Deactivate Physician
                    </button>
                  ) : (
                    <span className="block text-center py-2 text-xs text-slate-400 font-medium">
                      Physician Deactivated
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Doctor Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-purple-100 text-purple-800">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Register Clinic Physician
                  </h3>
                  <p className="text-xs text-slate-500">
                    Provisions doctor profile and generates temporary login credentials.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {createdDoctorResult ? (
              <div className="space-y-4 py-2">
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                  <div className="flex items-center gap-2 font-bold text-sm text-emerald-800 mb-1">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    Doctor Created Successfully!
                  </div>
                  <p className="text-xs text-emerald-700 leading-relaxed">
                    The physician has been added to the clinic system. Share the temporary password below so they can sign in:
                  </p>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">
                      Doctor ID
                    </span>
                    <span className="font-mono text-slate-800">{createdDoctorResult.doctor_id}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">
                      Generated Temporary Password
                    </span>
                    <div className="flex items-center justify-between gap-2 mt-1 bg-white p-2.5 rounded-lg border border-slate-300 font-mono text-sm font-bold text-purple-900">
                      <span>{createdDoctorResult.temporary_password}</span>
                      <button
                        type="button"
                        onClick={() => handleCopyPassword(createdDoctorResult.temporary_password)}
                        className="inline-flex items-center gap-1 text-xs px-2.5 py-1 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded-md transition font-sans font-medium"
                      >
                        {copiedPassword ? (
                          <>
                            <Check className="w-3.5 h-3.5" /> Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> Copy
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddModalOpen(false);
                      setCreatedDoctorResult(null);
                    }}
                    className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs rounded-xl transition shadow-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleAddDoctor} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Doctor Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Ayesha Siddiqui"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Clinic Email Address
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="doctor@nowsheraclinic.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Specialty / Department
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Cardiology, Pediatrics, General Practice"
                    value={formData.specialty}
                    onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    placeholder="03001234567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isAdding}
                    className="px-5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-lg transition shadow-xs flex items-center gap-1.5"
                  >
                    {isAdding ? 'Creating Doctor Account...' : 'Create Doctor'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Deactivate confirmation */}
      <ConfirmDialog
        isOpen={!!deactivateTarget}
        title="Deactivate Doctor"
        message={`Are you sure you want to deactivate ${deactivateTarget?.full_name}? They will no longer appear on public booking listings, and their current open slots will be disabled.`}
        confirmLabel="Yes, Deactivate Doctor"
        cancelLabel="Keep Active"
        variant="danger"
        isLoading={isDeactivating}
        onConfirm={handleConfirmDeactivate}
        onCancel={() => setDeactivateTarget(null)}
      />
    </div>
  );
};
