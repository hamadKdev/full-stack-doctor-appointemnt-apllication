import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminApi } from '../../api/admin';
import type { AdminDashboardData } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import {
  Users,
  Stethoscope,
  Calendar,
  CheckCircle2,
  AlertCircle,
  XCircle,
  UserX,
  ArrowRight,
  TrendingUp,
  Shield,
  Activity,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboard = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApi.getDashboard();
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load clinic administrative dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const stats = data?.stats;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 rounded-2xl text-white p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold mb-3 border border-purple-400/20">
            <Shield className="w-3.5 h-3.5" /> Clinic Administration & System Oversight
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
            Executive Clinic Dashboard
          </h1>
          <p className="text-sm text-purple-100/80 leading-relaxed mb-6">
            Real-time appointment volume, physician workload distribution, staff registry, and patient metrics for Nowshera Family Clinic.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/admin/doctors"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded-xl shadow-xs transition"
            >
              <Stethoscope className="w-4 h-4" /> Manage Physicians
            </Link>
            <Link
              to="/admin/appointments"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-medium text-xs rounded-xl border border-white/20 transition"
            >
              <Calendar className="w-4 h-4" /> All Appointments
            </Link>
          </div>
        </div>
      </div>

      {error && <ErrorMessage message={error} onRetry={fetchDashboard} onDismiss={() => setError(null)} />}

      {loading ? (
        <Loading message="Fetching administrative clinic telemetry..." />
      ) : (
        <>
          {/* Key Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider">Total Doctors</span>
                <Stethoscope className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {stats?.total_doctors ?? 0}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Specialists on roster</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider">Total Patients</span>
                <Users className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {stats?.total_patients ?? 0}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Registered patient accounts</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider">Appointments</span>
                <Calendar className="w-4 h-4 text-purple-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {stats?.total_appointments ?? 0}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Total bookings recorded</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider">Completed Visits</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                {stats?.completed_appointments ?? 0}
              </div>
              <p className="text-[11px] text-emerald-700 font-medium mt-1">Successfully finished</p>
            </div>
          </div>

          {/* Secondary Status Breakdown Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-amber-800 uppercase tracking-wider block">
                  Pending
                </span>
                <span className="text-lg font-bold text-amber-950">
                  {stats?.pending_appointments ?? 0}
                </span>
              </div>
              <AlertCircle className="w-5 h-5 text-amber-600" />
            </div>

            <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-blue-800 uppercase tracking-wider block">
                  Confirmed
                </span>
                <span className="text-lg font-bold text-blue-950">
                  {stats?.confirmed_appointments ?? 0}
                </span>
              </div>
              <CheckCircle2 className="w-5 h-5 text-blue-600" />
            </div>

            <div className="bg-rose-50/70 border border-rose-200/80 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-rose-800 uppercase tracking-wider block">
                  Cancelled / Rejected
                </span>
                <span className="text-lg font-bold text-rose-950">
                  {(stats?.cancelled_appointments ?? 0) + (stats?.rejected_appointments ?? 0)}
                </span>
              </div>
              <XCircle className="w-5 h-5 text-rose-600" />
            </div>

            <div className="bg-purple-50/70 border border-purple-200/80 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-purple-800 uppercase tracking-wider block">
                  No-Show
                </span>
                <span className="text-lg font-bold text-purple-950">
                  {stats?.no_show_appointments ?? 0}
                </span>
              </div>
              <UserX className="w-5 h-5 text-purple-600" />
            </div>
          </div>

          {/* Doctors Overview Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">Physician Workload Summary</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Consultation performance and status distribution per doctor.
                </p>
              </div>
              <Link
                to="/admin/doctors"
                className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1"
              >
                Doctor Management <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {(!data?.doctors || data.doctors.length === 0) ? (
              <p className="text-xs text-slate-500 py-4 text-center">No active doctors registered yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[11px]">
                      <th className="pb-3 font-semibold">Doctor Name</th>
                      <th className="pb-3 font-semibold">Specialty</th>
                      <th className="pb-3 font-semibold text-center">Total</th>
                      <th className="pb-3 font-semibold text-center">Pending</th>
                      <th className="pb-3 font-semibold text-center">Confirmed</th>
                      <th className="pb-3 font-semibold text-center">Completed</th>
                      <th className="pb-3 font-semibold text-center">Cancelled</th>
                      <th className="pb-3 font-semibold text-center">No-Show</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.doctors.map((doc) => (
                      <tr key={doc.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 font-bold text-slate-900">{doc.full_name}</td>
                        <td className="py-3 text-slate-600">
                          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
                            {doc.specialty}
                          </span>
                        </td>
                        <td className="py-3 text-center font-semibold text-slate-800">
                          {doc.total_appointments || 0}
                        </td>
                        <td className="py-3 text-center text-amber-700 font-medium">
                          {doc.pending_appointments || 0}
                        </td>
                        <td className="py-3 text-center text-blue-700 font-medium">
                          {doc.confirmed_appointments || 0}
                        </td>
                        <td className="py-3 text-center text-emerald-700 font-medium">
                          {doc.completed_appointments || 0}
                        </td>
                        <td className="py-3 text-center text-slate-500">
                          {doc.cancelled_appointments || 0}
                        </td>
                        <td className="py-3 text-center text-purple-700">
                          {doc.no_show_appointments || 0}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Today's Appointments Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">Today's Scheduled Consultations</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  All appointments scheduled for today across clinic departments.
                </p>
              </div>
              <Link
                to="/admin/appointments"
                className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1"
              >
                All Records <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {(!data?.today_appointments || data.today_appointments.length === 0) ? (
              <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                No consultations booked for today.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[11px]">
                      <th className="pb-3 font-semibold">Patient</th>
                      <th className="pb-3 font-semibold">Physician</th>
                      <th className="pb-3 font-semibold">Time Window</th>
                      <th className="pb-3 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.today_appointments.map((app) => (
                      <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 font-semibold text-slate-900">
                          {app.patient?.full_name || 'Patient'}
                        </td>
                        <td className="py-3 text-slate-700">
                          {app.doctor?.full_name || 'Physician'} ({app.doctor?.specialty})
                        </td>
                        <td className="py-3 text-slate-600 font-medium">
                          {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                        </td>
                        <td className="py-3">
                          <StatusBadge status={app.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
