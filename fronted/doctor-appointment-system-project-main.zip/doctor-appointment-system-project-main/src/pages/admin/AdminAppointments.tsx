import React, { useEffect, useState } from 'react';
import { adminApi } from '../../api/admin';
import type { Appointment, Doctor } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import {
  Calendar,
  Clock,
  User,
  Stethoscope,
  Filter,
  XCircle,
  CheckCircle2,
  X,
  Shield,
} from 'lucide-react';

export const AdminAppointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Filters
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Cancel Modal
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  // Load doctors for dropdown
  useEffect(() => {
    adminApi
      .getDoctors()
      .then((data) => setDoctors(data || []))
      .catch(() => {});
  }, []);

  const fetchAppointments = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await adminApi.getAppointments({
        doctor_id: selectedDoctorId || undefined,
        appointment_date: selectedDate || undefined,
        status: selectedStatus !== 'all' ? selectedStatus : undefined,
      });
      setAppointments(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve clinic appointments.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [selectedDoctorId, selectedDate, selectedStatus]);

  const handleConfirmCancel = async () => {
    if (!cancelTarget) return;
    setIsCancelling(true);
    setError(null);
    try {
      const res = await adminApi.cancelAppointment(cancelTarget.id);
      setSuccessMsg(res.message || 'Appointment cancelled by clinic administration.');
      setCancelTarget(null);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to cancel appointment.');
    } finally {
      setIsCancelling(false);
    }
  };

  const clearFilters = () => {
    setSelectedDoctorId('');
    setSelectedDate('');
    setSelectedStatus('all');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Clinic Master Appointment Schedule
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Monitor all scheduled consultations, apply administrative filters, and resolve booking conflicts.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {/* Filter Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
          <Filter className="w-3.5 h-3.5 text-purple-600" />
          <span>Filter Appointments</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {/* Doctor Dropdown */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Physician
            </label>
            <select
              value={selectedDoctorId}
              onChange={(e) => setSelectedDoctorId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-purple-500"
            >
              <option value="">All Physicians</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name} ({d.specialty})
                </option>
              ))}
            </select>
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Consultation Date
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
          </div>

          {/* Status Dropdown */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-purple-500"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="confirmed">Confirmed</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
              <option value="rejected">Rejected</option>
              <option value="no-show">No-Show</option>
            </select>
          </div>

          {/* Reset button */}
          <div className="flex items-end">
            <button
              type="button"
              onClick={clearFilters}
              className="w-full py-2 px-3 border border-slate-200 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-50 transition"
            >
              Reset Filters
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <Loading message="Filtering clinic appointments..." />
      ) : appointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No Appointments Found</h3>
          <p className="text-xs text-slate-500 mt-1">
            No consultations meet the selected filter criteria.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4 font-semibold">Patient</th>
                  <th className="py-3 px-4 font-semibold">Attending Doctor</th>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold">Time Window</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Admin Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.map((app) => {
                  const canCancel = app.status === 'pending' || app.status === 'confirmed';

                  return (
                    <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {app.patient?.full_name || 'Patient'}
                        {app.patient?.phone && (
                          <span className="block text-[10px] font-normal text-slate-400">
                            {app.patient.phone}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        <span className="font-semibold">{app.doctor?.full_name || 'Doctor'}</span>
                        <span className="block text-[10px] text-teal-700 font-medium">
                          {app.doctor?.specialty}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {app.appointment_date}
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={app.status} />
                      </td>
                      <td className="py-3 px-4 text-right">
                        {canCancel ? (
                          <button
                            type="button"
                            onClick={() => setCancelTarget(app)}
                            className="px-2.5 py-1 text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg transition"
                          >
                            Cancel
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!cancelTarget}
        title="Admin Cancel Appointment"
        message={`Are you sure you want to administratively cancel this appointment between ${
          cancelTarget?.patient?.full_name || 'Patient'
        } and ${cancelTarget?.doctor?.full_name || 'Doctor'} on ${cancelTarget?.appointment_date}?`}
        confirmLabel="Yes, Cancel Appointment"
        cancelLabel="Keep Booking"
        variant="danger"
        isLoading={isCancelling}
        onConfirm={handleConfirmCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
};
