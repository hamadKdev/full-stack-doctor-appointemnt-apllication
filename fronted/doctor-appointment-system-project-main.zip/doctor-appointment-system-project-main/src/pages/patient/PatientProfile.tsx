import React from 'react';
import { useAuth } from '../../auth/AuthContext';
import { User, Mail, Phone, ShieldCheck, Calendar, Activity } from 'lucide-react';

export const PatientProfile: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Patient Profile
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Personal contact information and verified medical portal account details.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-2xl shadow-inner">
            {user?.full_name?.charAt(0) || 'P'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">{user?.full_name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200">
                Registered Patient
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Nowshera Family Clinic Medical ID</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <User className="w-3.5 h-3.5" /> Full Name
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.full_name}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Mail className="w-3.5 h-3.5" /> Email Address
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.email}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Phone className="w-3.5 h-3.5" /> Contact Phone
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.phone || 'Not specified'}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" /> Portal Security
            </div>
            <p className="text-sm font-semibold text-emerald-700">Active JWT Authentication</p>
          </div>
        </div>

        <div className="mt-8 p-4 rounded-xl bg-teal-50 border border-teal-200/60 text-xs text-teal-900 flex items-start gap-3">
          <Activity className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Your appointment history, cancellations, and doctor's private consult notes are protected according to clinic patient confidentiality guidelines.
          </p>
        </div>
      </div>
    </div>
  );
};
