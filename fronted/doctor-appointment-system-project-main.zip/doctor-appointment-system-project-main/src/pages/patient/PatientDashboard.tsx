import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { patientApi } from '../../api/patient';
import type { Appointment } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import {
  CalendarPlus,
  Calendar,
  Clock,
  User,
  ArrowRight,
  CheckCircle,
  FileText,
  AlertCircle,
} from 'lucide-react';

export const PatientDashboard: React.FC = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const list = await patientApi.getMyAppointments();
      setAppointments(list || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load appointments.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  // Upcoming appointment (status: pending or confirmed, sorted by date/time)
  const upcomingAppointments = appointments
    .filter((a) => a.status === 'pending' || a.status === 'confirmed')
    .sort((a, b) => `${a.appointment_date} ${a.start_time}`.localeCompare(`${b.appointment_date} ${b.start_time}`));

  const nextAppointment = upcomingAppointments[0];

  return (
    <div className="space-y-6">
      {/* Welcome Card */}
      <div className="bg-gradient-to-r from-teal-700 to-teal-900 rounded-2xl text-white p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-teal-200 text-xs font-semibold mb-3">
            Patient Medical Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
            Welcome back, {user?.full_name}!
          </h1>
          <p className="text-sm text-teal-100 leading-relaxed mb-6">
            Easily book verified 30-minute doctor slots, monitor your upcoming clinical visits, and access private visit notes from attending specialists.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/patient/book"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white text-teal-900 hover:bg-teal-50 font-semibold text-sm rounded-xl shadow-xs transition"
            >
              <CalendarPlus className="w-4 h-4 text-teal-700" /> Book New Appointment
            </Link>
            <Link
              to="/patient/appointments"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-800/80 hover:bg-teal-800 text-white font-medium text-sm rounded-xl border border-teal-600/40 transition"
            >
              <Calendar className="w-4 h-4" /> My Appointments ({appointments.length})
            </Link>
          </div>
        </div>
      </div>

      {error && <ErrorMessage message={error} onRetry={fetchAppointments} onDismiss={() => setError(null)} />}

      {/* Next Upcoming Appointment Highlight */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-600" /> Next Upcoming Visit
            </h2>
            {nextAppointment && <StatusBadge status={nextAppointment.status} />}
          </div>

          {isLoading ? (
            <Loading message="Checking your schedule..." />
          ) : nextAppointment ? (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-bold text-lg text-slate-900">
                    {nextAppointment.doctor?.full_name || 'Assigned Specialist'}
                  </h3>
                  <p className="text-xs text-teal-700 font-semibold mt-0.5">
                    {nextAppointment.doctor?.specialty || 'General Consultation'}
                  </p>
                  <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5 font-medium">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <span>{nextAppointment.appointment_date}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-medium">
                      <Clock className="w-4 h-4 text-slate-400" />
                      <span>
                        {nextAppointment.start_time.slice(0, 5)} - {nextAppointment.end_time.slice(0, 5)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex sm:flex-col gap-2 shrink-0">
                  <Link
                    to="/patient/appointments"
                    className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 rounded-lg text-xs font-medium text-center transition"
                  >
                    Manage / Reschedule
                  </Link>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 px-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              <CheckCircle className="w-8 h-8 text-teal-600 mx-auto mb-2 opacity-80" />
              <p className="text-sm font-semibold text-slate-700">No upcoming appointments scheduled</p>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Choose an available slot with one of our specialized clinicians.
              </p>
              <Link
                to="/patient/book"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold transition"
              >
                Book a Consultation
              </Link>
            </div>
          )}
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-teal-600" /> Patient Info
              </h2>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                Verified
              </span>
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block uppercase tracking-wider text-[10px]">Full Name</span>
                <span className="font-semibold text-slate-800 text-sm">{user?.full_name}</span>
              </div>
              <div>
                <span className="text-slate-400 block uppercase tracking-wider text-[10px]">Email Address</span>
                <span className="font-medium text-slate-700">{user?.email}</span>
              </div>
              <div>
                <span className="text-slate-400 block uppercase tracking-wider text-[10px]">Contact Phone</span>
                <span className="font-medium text-slate-700">{user?.phone || 'Not recorded'}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <Link to="/patient/history" className="text-teal-700 hover:text-teal-800 font-semibold flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" /> Visit Logs
            </Link>
            <Link to="/patient/profile" className="text-slate-500 hover:text-slate-700 font-medium">
              View Profile →
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Appointments List */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Recent Appointments</h2>
            <p className="text-xs text-slate-500 mt-0.5">Overview of your consultations and requests</p>
          </div>
          <Link
            to="/patient/appointments"
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
          >
            All Appointments <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {isLoading ? (
          <Loading message="Loading appointment records..." />
        ) : appointments.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            <AlertCircle className="w-8 h-8 mx-auto text-slate-400 mb-2" />
            No appointment records found yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[11px]">
                  <th className="pb-3 font-semibold">Doctor</th>
                  <th className="pb-3 font-semibold">Specialty</th>
                  <th className="pb-3 font-semibold">Date</th>
                  <th className="pb-3 font-semibold">Time</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.slice(0, 5).map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 font-semibold text-slate-900">
                      {app.doctor?.full_name || 'Specialist'}
                    </td>
                    <td className="py-3 text-slate-600">{app.doctor?.specialty || 'Consultation'}</td>
                    <td className="py-3 text-slate-600">{app.appointment_date}</td>
                    <td className="py-3 text-slate-600 font-medium">
                      {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                    </td>
                    <td className="py-3">
                      <StatusBadge status={app.status} />
                    </td>
                    <td className="py-3 text-right">
                      <Link
                        to="/patient/appointments"
                        className="text-teal-700 hover:text-teal-900 font-semibold"
                      >
                        Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
