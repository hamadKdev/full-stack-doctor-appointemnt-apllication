import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { patientApi } from '../../api/patient';
import type { Doctor, AppointmentSlot } from '../../types';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import {
  Stethoscope,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Check,
} from 'lucide-react';

export const BookAppointment: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(
    searchParams.get('doctor') || ''
  );

  // Today's date YYYY-MM-DD in local time
  const getTodayString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [selectedDate, setSelectedDate] = useState<string>(getTodayString());
  const [slots, setSlots] = useState<AppointmentSlot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<AppointmentSlot | null>(null);

  const [loadingDoctors, setLoadingDoctors] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successBooking, setSuccessBooking] = useState<{
    message: string;
    appointment: any;
  } | null>(null);

  // 1. Fetch available doctors
  useEffect(() => {
    setLoadingDoctors(true);
    patientApi
      .getDoctors()
      .then((data) => {
        setDoctors(data || []);
        if (!selectedDoctorId && data && data.length > 0) {
          setSelectedDoctorId(data[0].id);
        }
      })
      .catch((err: any) => setError(err.message || 'Failed to load doctors list.'))
      .finally(() => setLoadingDoctors(false));
  }, []);

  // 2. Fetch available slots when doctor or date changes
  useEffect(() => {
    if (!selectedDoctorId || !selectedDate) {
      setSlots([]);
      setSelectedSlot(null);
      return;
    }

    setLoadingSlots(true);
    setError(null);
    setSelectedSlot(null);

    patientApi
      .getDoctorSlots(selectedDoctorId, selectedDate)
      .then((data) => {
        setSlots(data || []);
      })
      .catch((err: any) => {
        setError(err.message || 'Failed to fetch doctor slots.');
        setSlots([]);
      })
      .finally(() => {
        setLoadingSlots(false);
      });
  }, [selectedDoctorId, selectedDate]);

  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId);

  const handleBook = async () => {
    if (!selectedDoctorId || !selectedDate || !selectedSlot) {
      setError('Please select a doctor, date, and available 30-minute slot.');
      return;
    }

    setBookingLoading(true);
    setError(null);

    try {
      const res = await patientApi.bookAppointment({
        doctor_id: selectedDoctorId,
        appointment_date: selectedDate,
        start_time: selectedSlot.start_time,
      });

      setSuccessBooking(res);
    } catch (err: any) {
      setError(err.message || 'Could not complete booking.');
    } finally {
      setBookingLoading(false);
    }
  };

  if (successBooking) {
    return (
      <div className="max-w-xl mx-auto py-12 px-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">
            Appointment Requested!
          </h2>
          <p className="text-sm text-slate-600 mb-6 leading-relaxed">
            {successBooking.message ||
              'Your appointment request has been submitted and is currently Pending doctor confirmation.'}
          </p>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left text-xs text-slate-700 space-y-2 mb-6">
            <div className="flex justify-between">
              <span className="text-slate-400">Doctor:</span>
              <span className="font-semibold text-slate-900">
                {selectedDoctor?.full_name} ({selectedDoctor?.specialty})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Date:</span>
              <span className="font-semibold text-slate-900">{selectedDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Time Slot:</span>
              <span className="font-semibold text-slate-900">
                {selectedSlot?.start_time} - {selectedSlot?.end_time}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Current Status:</span>
              <span className="inline-flex items-center gap-1 font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                Pending Confirmation
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              type="button"
              onClick={() => {
                setSuccessBooking(null);
                setSelectedSlot(null);
              }}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-medium text-xs hover:bg-slate-50 transition"
            >
              Book Another
            </button>
            <button
              type="button"
              onClick={() => navigate('/patient/appointments')}
              className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition shadow-xs"
            >
              View My Appointments
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Book Doctor Appointment
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Select specialist, choose date, and pick from real-time available 30-minute consultation slots.
        </p>
      </div>

      {error && (
        <ErrorMessage
          message={error}
          onDismiss={() => setError(null)}
          className="mb-4"
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Step 1 & 2: Doctor and Date Selection */}
        <div className="lg:col-span-2 space-y-6">
          {/* Step 1: Choose Doctor */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs font-bold flex items-center justify-center">
                1
              </span>
              <h2 className="text-base font-bold text-slate-900">Choose Specialist</h2>
            </div>

            {loadingDoctors ? (
              <Loading message="Loading registered clinicians..." />
            ) : doctors.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs">
                No active doctors available for booking at this time.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {doctors.map((doc) => {
                  const isSelected = doc.id === selectedDoctorId;
                  return (
                    <button
                      key={doc.id}
                      type="button"
                      onClick={() => setSelectedDoctorId(doc.id)}
                      className={`p-4 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                        isSelected
                          ? 'border-teal-600 bg-teal-50/50 ring-2 ring-teal-500/20'
                          : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">{doc.full_name}</h4>
                          <span className="inline-block mt-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-teal-100/70 text-teal-800">
                            {doc.specialty}
                          </span>
                        </div>
                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3" />
                          </span>
                        )}
                      </div>
                      {doc.phone && (
                        <span className="text-[11px] text-slate-500 mt-3 block">
                          Phone: {doc.phone}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Step 2: Choose Date */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h2 className="text-base font-bold text-slate-900">Select Date</h2>
            </div>

            <div className="max-w-xs">
              <label className="block text-xs font-medium text-slate-600 mb-1.5">
                Appointment Date (Upcoming days only)
              </label>
              <div className="relative">
                <input
                  type="date"
                  min={getTodayString()}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Step 3: Choose Free Slots */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs font-bold flex items-center justify-center">
                  3
                </span>
                <h2 className="text-base font-bold text-slate-900">
                  Available 30-Minute Slots
                </h2>
              </div>
              <span className="text-xs text-slate-500">
                {slots.length} slot{slots.length === 1 ? '' : 's'} free
              </span>
            </div>

            {loadingSlots ? (
              <Loading message="Querying live clinician calendar..." />
            ) : slots.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-500">
                <AlertCircle className="w-7 h-7 text-slate-400 mx-auto mb-2" />
                <p className="font-medium text-slate-700 text-sm">
                  No available slots for this date
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  The clinician may not have working hours configured on this day of the week, may be on approved leave, or all appointment slots have been booked.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {slots.map((slot) => {
                  const isSelected =
                    selectedSlot?.start_time === slot.start_time &&
                    selectedSlot?.end_time === slot.end_time;
                  return (
                    <button
                      key={`${slot.start_time}-${slot.end_time}`}
                      type="button"
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-3 py-3 rounded-xl border text-center font-medium text-xs transition flex flex-col items-center justify-center gap-1 ${
                        isSelected
                          ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                      }`}
                    >
                      <span className="text-sm font-bold tracking-tight">
                        {slot.start_time}
                      </span>
                      <span className={`text-[10px] ${isSelected ? 'text-teal-100' : 'text-slate-400'}`}>
                        to {slot.end_time}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Step 4: Summary & Confirm Sidebar */}
        <div>
          <div className="sticky top-20 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
            <h3 className="font-bold text-slate-900 text-base pb-3 border-b border-slate-100">
              Booking Summary
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                  Doctor
                </span>
                <span className="font-bold text-slate-900 text-sm">
                  {selectedDoctor ? selectedDoctor.full_name : 'None selected'}
                </span>
                {selectedDoctor && (
                  <span className="text-teal-700 block font-medium">
                    {selectedDoctor.specialty}
                  </span>
                )}
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                  Consultation Date
                </span>
                <span className="font-semibold text-slate-800 text-sm">
                  {selectedDate || 'Select a date'}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                  Selected Slot
                </span>
                {selectedSlot ? (
                  <span className="font-bold text-teal-700 text-sm">
                    {selectedSlot.start_time} - {selectedSlot.end_time}
                  </span>
                ) : (
                  <span className="text-slate-400 italic">No slot selected</span>
                )}
              </div>

              <div className="pt-2 border-t border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                  Initial Status
                </span>
                <span className="inline-block mt-0.5 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                  Pending Doctor Approval
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                disabled={!selectedDoctorId || !selectedDate || !selectedSlot || bookingLoading}
                onClick={handleBook}
                className="w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 transition shadow-xs flex items-center justify-center gap-2"
              >
                {bookingLoading ? (
                  'Submitting Request...'
                ) : (
                  <>
                    Confirm Booking <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

            <p className="text-[11px] text-slate-400 text-center leading-relaxed">
              Once submitted, your appointment begins in <strong className="text-slate-600">Pending</strong> status. Rescheduling and cancellation are permitted up to 2 hours before the start time.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
