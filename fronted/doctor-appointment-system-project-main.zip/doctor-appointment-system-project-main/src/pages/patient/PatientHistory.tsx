import React, { useEffect, useState } from 'react';
import { patientApi } from '../../api/patient';
import type { Appointment, VisitNoteItem } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { FileText, Calendar, Clock, Stethoscope, ChevronRight, X } from 'lucide-react';

export const PatientHistory: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeNoteAppointment, setActiveNoteAppointment] = useState<Appointment | null>(null);
  const [notes, setNotes] = useState<VisitNoteItem[]>([]);
  const [loadingNote, setLoadingNote] = useState(false);

  useEffect(() => {
    patientApi
      .getMyAppointments()
      .then((data) => {
        setAppointments(data || []);
      })
      .catch((err: any) => setError(err.message || 'Failed to fetch visit history.'))
      .finally(() => setLoading(false));
  }, []);

  const handleOpenNote = async (appointment: Appointment) => {
    setActiveNoteAppointment(appointment);
    setLoadingNote(true);
    setNotes([]);
    try {
      const res = await patientApi.getAppointmentNote(appointment.id);
      setNotes(res || []);
    } catch (err: any) {
      setError(err.message || 'Unable to retrieve visit note.');
    } finally {
      setLoadingNote(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Patient Visit History
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Complete chronological record of your clinic appointments and confidential visit notes.
        </p>
      </div>

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {loading ? (
        <Loading message="Loading your consultation history..." />
      ) : appointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No Visit Records</h3>
          <p className="text-xs text-slate-500 mt-1">
            You do not have any past clinic visits or consultation records recorded yet.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="divide-y divide-slate-100">
            {appointments.map((app) => (
              <div
                key={app.id}
                className="p-5 sm:p-6 hover:bg-slate-50/70 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-slate-900 text-base">
                      {app.doctor?.full_name || 'Specialist Clinician'}
                    </span>
                    <StatusBadge status={app.status} />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-teal-700 font-semibold">
                    <Stethoscope className="w-3.5 h-3.5" />
                    <span>{app.doctor?.specialty || 'General Practice'}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-500 font-medium">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {app.appointment_date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                    </span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center">
                  <button
                    type="button"
                    onClick={() => handleOpenNote(app)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-800 border border-slate-200 hover:border-teal-200 transition"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    View Visit Note
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Note Modal */}
      {activeNoteAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-50 text-teal-700">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Clinical Visit Notes
                  </h3>
                  <p className="text-xs text-slate-500">
                    {activeNoteAppointment.doctor?.full_name} • {activeNoteAppointment.appointment_date}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveNoteAppointment(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {loadingNote ? (
              <Loading message="Fetching note..." />
            ) : notes.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                No clinical notes recorded for this visit.
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {notes.map((item, idx) => (
                  <div key={item.id || idx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                    <p className="text-slate-800 text-sm whitespace-pre-wrap leading-relaxed">
                      {item.note}
                    </p>
                    {item.created_at && (
                      <span className="text-[10px] text-slate-400 block mt-2">
                        Recorded on {new Date(item.created_at).toLocaleString()}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}

            <div className="mt-6 pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveNoteAppointment(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
