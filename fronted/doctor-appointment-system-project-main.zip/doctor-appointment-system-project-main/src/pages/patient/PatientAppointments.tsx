import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { patientApi } from '../../api/patient';
import type { Appointment, AppointmentSlot, VisitNoteItem } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import {
  Calendar,
  Clock,
  Stethoscope,
  X,
  RefreshCw,
  FileText,
  AlertTriangle,
  CheckCircle,
  CalendarPlus,
} from 'lucide-react';

export const PatientAppointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Cancellation state
  const [cancelModalAppointment, setCancelModalAppointment] = useState<Appointment | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  // Reschedule state
  const [rescheduleAppointment, setRescheduleAppointment] = useState<Appointment | null>(null);
  const [newDate, setNewDate] = useState<string>('');
  const [rescheduleSlots, setRescheduleSlots] = useState<AppointmentSlot[]>([]);
  const [selectedRescheduleSlot, setSelectedRescheduleSlot] = useState<AppointmentSlot | null>(null);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [isRescheduling, setIsRescheduling] = useState(false);

  // Visit Note Modal state
  const [noteModalAppointment, setNoteModalAppointment] = useState<Appointment | null>(null);
  const [visitNotes, setVisitNotes] = useState<VisitNoteItem[]>([]);
  const [loadingNote, setLoadingNote] = useState(false);

  // Rule 2 hours check
  const isMoreThan2HoursAway = (dateStr: string, timeStr: string): boolean => {
    try {
      // timeStr may be "10:00:00" or "10:00"
      const [hours, minutes] = timeStr.split(':').map(Number);
      const appDate = new Date(dateStr);
      appDate.setHours(hours, minutes, 0, 0);

      const now = new Date();
      const diffMs = appDate.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      return diffHours >= 2;
    } catch {
      return false;
    }
  };

  const fetchAppointments = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await patientApi.getMyAppointments();
      setAppointments(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load appointments.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  // Fetch slots for reschedule
  useEffect(() => {
    if (!rescheduleAppointment || !newDate) {
      setRescheduleSlots([]);
      setSelectedRescheduleSlot(null);
      return;
    }

    setLoadingSlots(true);
    const doctorId = rescheduleAppointment.doctor_id || rescheduleAppointment.doctor?.id;
    if (!doctorId) {
      setLoadingSlots(false);
      return;
    }

    patientApi
      .getDoctorSlots(doctorId, newDate)
      .then((data) => {
        setRescheduleSlots(data || []);
      })
      .catch((err: any) => {
        setError(err.message || 'Failed to load slots for selected date.');
        setRescheduleSlots([]);
      })
      .finally(() => {
        setLoadingSlots(false);
      });
  }, [rescheduleAppointment, newDate]);

  // Handle Cancel
  const handleConfirmCancel = async () => {
    if (!cancelModalAppointment) return;
    setIsCancelling(true);
    setError(null);
    try {
      const res = await patientApi.cancelAppointment(cancelModalAppointment.id);
      setSuccessMsg(res.message || 'Appointment cancelled successfully.');
      setCancelModalAppointment(null);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to cancel appointment.');
    } finally {
      setIsCancelling(false);
    }
  };

  // Handle Reschedule
  const handleConfirmReschedule = async () => {
    if (!rescheduleAppointment || !newDate || !selectedRescheduleSlot) {
      setError('Please select a new date and an available slot.');
      return;
    }

    setIsRescheduling(true);
    setError(null);
    try {
      const res = await patientApi.rescheduleAppointment(rescheduleAppointment.id, {
        appointment_date: newDate,
        start_time: selectedRescheduleSlot.start_time,
      });

      setSuccessMsg(
        res.message || 'Appointment rescheduled successfully and waiting for confirmation.'
      );
      setRescheduleAppointment(null);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to reschedule appointment.');
    } finally {
      setIsRescheduling(false);
    }
  };

  // View note
  const handleOpenNote = async (appointment: Appointment) => {
    setNoteModalAppointment(appointment);
    setLoadingNote(true);
    setVisitNotes([]);
    try {
      const notes = await patientApi.getAppointmentNote(appointment.id);
      setVisitNotes(notes || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load visit note.');
    } finally {
      setLoadingNote(false);
    }
  };

  const getTodayString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            My Appointments
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track consultation requests, manage dates, and inspect your scheduled clinic visits.
          </p>
        </div>
        <Link
          to="/patient/book"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl shadow-xs transition"
        >
          <CalendarPlus className="w-4 h-4" /> Book New Slot
        </Link>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {/* Appointment Cards / Table */}
      {loading ? (
        <Loading message="Fetching appointment records from clinic database..." />
      ) : appointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No appointments booked yet</h3>
          <p className="text-xs text-slate-500 mt-1 mb-6 max-w-sm mx-auto">
            Choose a specialist from Nowshera Family Clinic and reserve an available 30-minute consultation slot.
          </p>
          <Link
            to="/patient/book"
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl shadow-xs transition"
          >
            <CalendarPlus className="w-4 h-4" /> Book an Appointment
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {appointments.map((app) => {
            const canModify =
              (app.status === 'pending' || app.status === 'confirmed') &&
              isMoreThan2HoursAway(app.appointment_date, app.start_time);

            const isBlockedBy2HourRule =
              (app.status === 'pending' || app.status === 'confirmed') &&
              !isMoreThan2HoursAway(app.appointment_date, app.start_time);

            return (
              <div
                key={app.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:border-slate-300 transition flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="text-base font-bold text-slate-900">
                      {app.doctor?.full_name || 'Specialist Doctor'}
                    </h3>
                    <StatusBadge status={app.status} />
                  </div>

                  <p className="text-xs text-teal-700 font-semibold flex items-center gap-1.5">
                    <Stethoscope className="w-3.5 h-3.5" />
                    {app.doctor?.specialty || 'General Consultation'}
                  </p>

                  <div className="flex flex-wrap items-center gap-5 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5 font-medium">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <span>{app.appointment_date}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-medium">
                      <Clock className="w-4 h-4 text-slate-400" />
                      <span>
                        {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                      </span>
                    </div>
                  </div>

                  {isBlockedBy2HourRule && (
                    <div className="inline-flex items-center gap-1.5 text-[11px] text-amber-700 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>
                        Cancellation and rescheduling are only allowed up to 2 hours before the appointment.
                      </span>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-2.5 pt-4 md:pt-0 border-t md:border-t-0 border-slate-100">
                  {/* Reschedule Button */}
                  {(app.status === 'pending' || app.status === 'confirmed') && (
                    <button
                      type="button"
                      disabled={!canModify}
                      onClick={() => {
                        setRescheduleAppointment(app);
                        setNewDate(app.appointment_date);
                        setSelectedRescheduleSlot(null);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-semibold transition border ${
                        canModify
                          ? 'border-slate-300 hover:bg-slate-50 text-slate-700'
                          : 'border-slate-200 text-slate-400 opacity-60 cursor-not-allowed'
                      }`}
                      title={
                        !canModify
                          ? 'Cancellation and rescheduling are only allowed up to 2 hours before the appointment.'
                          : 'Change appointment date or time'
                      }
                    >
                      Reschedule
                    </button>
                  )}

                  {/* Cancel Button */}
                  {(app.status === 'pending' || app.status === 'confirmed') && (
                    <button
                      type="button"
                      disabled={!canModify}
                      onClick={() => setCancelModalAppointment(app)}
                      className={`px-3 py-2 rounded-xl text-xs font-semibold transition border ${
                        canModify
                          ? 'border-rose-200 hover:bg-rose-50 text-rose-600'
                          : 'border-slate-200 text-slate-400 opacity-60 cursor-not-allowed'
                      }`}
                      title={
                        !canModify
                          ? 'Cancellation and rescheduling are only allowed up to 2 hours before the appointment.'
                          : 'Cancel this appointment'
                      }
                    >
                      Cancel
                    </button>
                  )}

                  {/* Visit Note Button */}
                  {(app.status === 'completed' || app.status === 'confirmed' || app.status === 'no-show') && (
                    <button
                      type="button"
                      onClick={() => handleOpenNote(app)}
                      className="px-3 py-2 rounded-xl text-xs font-semibold bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition flex items-center gap-1.5"
                    >
                      <FileText className="w-3.5 h-3.5" /> Visit Note
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cancel Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!cancelModalAppointment}
        title="Cancel Appointment"
        message={`Are you sure you want to cancel your consultation with ${
          cancelModalAppointment?.doctor?.full_name || 'the specialist'
        } on ${cancelModalAppointment?.appointment_date}? This will release the 30-minute slot for other patients.`}
        confirmLabel="Yes, Cancel Booking"
        cancelLabel="Keep Booking"
        variant="danger"
        isLoading={isCancelling}
        onConfirm={handleConfirmCancel}
        onCancel={() => setCancelModalAppointment(null)}
      />

      {/* Reschedule Modal */}
      {rescheduleAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Reschedule Appointment
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  With {rescheduleAppointment.doctor?.full_name} ({rescheduleAppointment.doctor?.specialty})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRescheduleAppointment(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Choose New Date
                </label>
                <input
                  type="date"
                  min={getTodayString()}
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Select Available Slot
                  </label>
                  <span className="text-[11px] text-slate-500">
                    {rescheduleSlots.length} available
                  </span>
                </div>

                {loadingSlots ? (
                  <Loading message="Checking doctor schedule..." size="sm" />
                ) : rescheduleSlots.length === 0 ? (
                  <div className="p-4 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500">
                    No free slots available for this date. Please pick another date.
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1">
                    {rescheduleSlots.map((slot) => {
                      const isSelected =
                        selectedRescheduleSlot?.start_time === slot.start_time;
                      return (
                        <button
                          key={`${slot.start_time}-${slot.end_time}`}
                          type="button"
                          onClick={() => setSelectedRescheduleSlot(slot)}
                          className={`py-2 px-2.5 rounded-lg border text-center text-xs font-semibold transition ${
                            isSelected
                              ? 'bg-teal-600 text-white border-teal-600'
                              : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          {slot.start_time} - {slot.end_time}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-800 leading-relaxed">
                Notice: When rescheduled, your old slot becomes free for other patients, and the new appointment status resets to <strong>Pending</strong> awaiting doctor confirmation.
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRescheduleAppointment(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!newDate || !selectedRescheduleSlot || isRescheduling}
                  onClick={handleConfirmReschedule}
                  className="px-5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-lg transition shadow-xs flex items-center gap-1.5"
                >
                  {isRescheduling ? 'Rescheduling...' : 'Confirm Reschedule'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Visit Note Modal */}
      {noteModalAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-50 text-teal-700">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Private Visit Clinical Note
                  </h3>
                  <p className="text-xs text-slate-500">
                    Visit with {noteModalAppointment.doctor?.full_name} on {noteModalAppointment.appointment_date}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setNoteModalAppointment(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {loadingNote ? (
              <Loading message="Loading encrypted clinical note..." />
            ) : visitNotes.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs">
                No visit notes have been filed by the attending doctor for this consultation yet.
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {visitNotes.map((item, idx) => (
                  <div key={item.id || idx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                    <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-semibold mb-2">
                      <span>Clinical Assessment</span>
                      {item.created_at && (
                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                      )}
                    </div>
                    <p className="text-slate-800 text-sm whitespace-pre-wrap leading-relaxed">
                      {item.note}
                    </p>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-6 pt-3 border-t border-slate-100 flex justify-between items-center text-[11px] text-slate-400">
              <span>Confidential medical record.</span>
              <button
                type="button"
                onClick={() => setNoteModalAppointment(null)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
