import React from 'react';
import { useAuth } from '../../auth/AuthContext';
import { Stethoscope, Mail, Phone, Clock, ShieldCheck, Award } from 'lucide-react';

export const DoctorProfile: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Doctor Profile
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Specialist credentials, assigned clinic department, and staff access privileges.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-2xl shadow-inner">
            <Stethoscope className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">Dr. {user?.full_name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200">
                Medical Specialist
              </span>
            </div>
            <p className="text-xs font-semibold text-teal-700 mt-0.5">
              Specialty: {user?.specialty || 'General Practice'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Award className="w-3.5 h-3.5" /> Department / Specialty
            </div>
            <p className="text-sm font-semibold text-slate-800">
              {user?.specialty || 'General Practice'}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Mail className="w-3.5 h-3.5" /> Clinic Email
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.email}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Phone className="w-3.5 h-3.5" /> Direct Contact
            </div>
            <p className="text-sm font-semibold text-slate-800">{user?.phone || 'Not recorded'}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5" /> Consultation Unit
            </div>
            <p className="text-sm font-semibold text-teal-700">30-Minute Dynamic Slots</p>
          </div>
        </div>

        <div className="mt-8 p-4 rounded-xl bg-teal-50 border border-teal-200 text-xs text-teal-900 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Medical confidentiality policy: You possess full clinical authority to document, sign, and review patient notes. These remain strictly private to you and your attending patient.
          </p>
        </div>
      </div>
    </div>
  );
};
