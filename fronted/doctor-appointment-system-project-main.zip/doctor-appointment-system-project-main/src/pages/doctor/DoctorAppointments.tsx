import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { doctorApi } from '../../api/doctor';
import type { Appointment } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import {
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  CheckCircle2,
  XCircle,
  FileCheck2,
  UserX,
  History,
  X,
  Filter,
} from 'lucide-react';

export const DoctorAppointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');

  // Finish Visit Modal (Complete or No-Show)
  const [finishModalAppointment, setFinishModalAppointment] = useState<Appointment | null>(null);
  const [finishStatus, setFinishStatus] = useState<'completed' | 'no-show'>('completed');
  const [visitNote, setVisitNote] = useState<string>('');
  const [isFinishing, setIsFinishing] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  const fetchAppointments = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await doctorApi.getMyAppointments();
      setAppointments(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve appointments.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const handleConfirm = async (id: string) => {
    setActionLoadingId(id);
    setError(null);
    try {
      const res = await doctorApi.confirmAppointment(id);
      setSuccessMsg(res.message || 'Appointment confirmed.');
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to confirm appointment.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (id: string) => {
    setActionLoadingId(id);
    setError(null);
    try {
      const res = await doctorApi.rejectAppointment(id);
      setSuccessMsg(res.message || 'Appointment rejected.');
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to reject appointment.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleOpenFinishModal = (app: Appointment, status: 'completed' | 'no-show') => {
    setFinishModalAppointment(app);
    setFinishStatus(status);
    setVisitNote(
      status === 'completed'
        ? 'Patient examined. Prescription and recovery instructions provided.'
        : 'Patient did not arrive for the scheduled 30-minute consultation window.'
    );
  };

  const handleConfirmFinish = async () => {
    if (!finishModalAppointment) return;
    if (!visitNote.trim()) {
      setError('A visit clinical note is required.');
      return;
    }

    setIsFinishing(true);
    setError(null);
    try {
      const res = await doctorApi.finishVisit(
        finishModalAppointment.id,
        finishStatus,
        visitNote.trim()
      );
      setSuccessMsg(res.message || `Visit marked as ${finishStatus}.`);
      setFinishModalAppointment(null);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to complete visit.');
    } finally {
      setIsFinishing(false);
    }
  };

  // Filter logic
  const filteredAppointments = appointments.filter((app) => {
    if (statusFilter !== 'all') {
      const normalized = (app.status || '').toLowerCase().replace('_', '-');
      if (statusFilter === 'other') {
        if (['pending', 'confirmed', 'completed'].includes(normalized)) return false;
      } else if (normalized !== statusFilter) {
        return false;
      }
    }
    if (dateFilter && app.appointment_date !== dateFilter) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Doctor Appointments
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Confirm patient bookings, execute consultations, and document visit records.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center justify-between">
          <span>{successMsg}</span>
          <button
            type="button"
            onClick={() => setSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        {/* Status Tabs */}
        <div className="flex flex-wrap gap-1.5">
          {[
            { key: 'all', label: 'All' },
            { key: 'pending', label: 'Pending' },
            { key: 'confirmed', label: 'Confirmed' },
            { key: 'completed', label: 'Completed' },
            { key: 'other', label: 'Cancelled / Other' },
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setStatusFilter(tab.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                statusFilter === tab.key
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          {dateFilter && (
            <button
              type="button"
              onClick={() => setDateFilter('')}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <Loading message="Loading patient schedules..." />
      ) : filteredAppointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No appointments match criteria</h3>
          <p className="text-xs text-slate-500 mt-1">
            Try adjusting your status filter or selected date.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredAppointments.map((app) => {
            const isPending = app.status === 'pending';
            const isConfirmed = app.status === 'confirmed';

            return (
              <div
                key={app.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:border-slate-300 transition flex flex-col lg:flex-row lg:items-center justify-between gap-6"
              >
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-bold text-base text-slate-900">
                      {app.patient?.full_name || 'Registered Patient'}
                    </span>
                    <StatusBadge status={app.status} />
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                    <span className="flex items-center gap-1 font-semibold text-slate-800">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {app.appointment_date}
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-slate-800">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                    </span>
                    {app.patient?.phone && (
                      <span className="flex items-center gap-1 text-slate-500">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        {app.patient.phone}
                      </span>
                    )}
                    {app.patient?.email && (
                      <span className="flex items-center gap-1 text-slate-500">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        {app.patient.email}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-2 pt-4 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                  {/* Patient History quick link */}
                  <Link
                    to={`/doctor/patients?patient_id=${app.patient_id}`}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold transition flex items-center gap-1"
                    title="View this patient's past medical history"
                  >
                    <History className="w-3.5 h-3.5 text-slate-400" /> Medical History
                  </Link>

                  {/* If Pending: Confirm or Reject */}
                  {isPending && (
                    <>
                      <button
                        type="button"
                        disabled={actionLoadingId === app.id}
                        onClick={() => handleConfirm(app.id)}
                        className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition shadow-xs disabled:opacity-50 flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Confirm
                      </button>
                      <button
                        type="button"
                        disabled={actionLoadingId === app.id}
                        onClick={() => handleReject(app.id)}
                        className="px-3.5 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 font-semibold text-xs transition disabled:opacity-50 flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Reject
                      </button>
                    </>
                  )}

                  {/* If Confirmed: Complete or Mark No-Show */}
                  {isConfirmed && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleOpenFinishModal(app, 'completed')}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition shadow-xs flex items-center gap-1.5"
                      >
                        <FileCheck2 className="w-3.5 h-3.5" /> Complete Visit
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenFinishModal(app, 'no-show')}
                        className="px-3.5 py-1.5 rounded-lg border border-purple-200 hover:bg-purple-50 text-purple-700 font-semibold text-xs transition flex items-center gap-1.5"
                      >
                        <UserX className="w-3.5 h-3.5" /> Mark No-Show
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Finish Visit Modal */}
      {finishModalAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {finishStatus === 'completed' ? 'Complete Patient Consultation' : 'Mark Patient as No-Show'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Patient: {finishModalAppointment.patient?.full_name} • {finishModalAppointment.appointment_date} (
                  {finishModalAppointment.start_time.slice(0, 5)})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setFinishModalAppointment(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Clinical Visit Note (Mandatory)
                </label>
                <textarea
                  rows={4}
                  required
                  value={visitNote}
                  onChange={(e) => setVisitNote(e.target.value)}
                  placeholder="Record symptoms, diagnosis, prescribed treatments, or attendance notes..."
                  className="w-full p-3 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 leading-relaxed"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
                <strong>Medical Confidentiality Rule:</strong> This note is stored securely and is only accessible by you (attending clinician) and this patient. Clinic administrators cannot view this note.
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  disabled={isFinishing}
                  onClick={() => setFinishModalAppointment(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isFinishing || !visitNote.trim()}
                  onClick={handleConfirmFinish}
                  className={`px-5 py-2 text-xs font-semibold text-white rounded-lg transition shadow-xs flex items-center gap-1.5 disabled:opacity-50 ${
                    finishStatus === 'completed'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-purple-600 hover:bg-purple-700'
                  }`}
                >
                  {isFinishing ? 'Saving Record...' : finishStatus === 'completed' ? 'Finalize Visit' : 'Confirm No-Show'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
