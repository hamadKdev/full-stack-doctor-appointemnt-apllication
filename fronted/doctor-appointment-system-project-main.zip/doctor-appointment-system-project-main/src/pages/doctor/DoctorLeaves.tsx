import React, { useState } from 'react';
import { doctorApi } from '../../api/doctor';
import { ErrorMessage } from '../../components/ErrorMessage';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import { CalendarOff, AlertTriangle, CheckCircle2, Calendar, ShieldAlert } from 'lucide-react';

export const DoctorLeaves: React.FC = () => {
  const getTodayString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [leaveDate, setLeaveDate] = useState<string>(getTodayString());
  const [reason, setReason] = useState<string>('');
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleOpenConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!leaveDate) {
      setError('Please choose a valid leave date.');
      return;
    }

    setIsConfirmOpen(true);
  };

  const handleApplyLeave = async () => {
    setIsSubmitting(true);
    setError(null);
    try {
      const res = await doctorApi.addLeave({
        leave_date: leaveDate,
        reason: reason.trim() || undefined,
      });

      setSuccessMsg(
        res.message ||
          `Leave recorded for ${leaveDate}. Any existing booked appointments on this date have been cancelled.`
      );
      setIsConfirmOpen(false);
      setReason('');
    } catch (err: any) {
      setError(err.message || 'Failed to apply doctor leave.');
      setIsConfirmOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Doctor Leave Days
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Mark scheduled absences and automatically free or cancel conflicting patient appointments.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <form onSubmit={handleOpenConfirm} className="space-y-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Leave Date
            </label>
            <input
              type="date"
              required
              min={getTodayString()}
              value={leaveDate}
              onChange={(e) => setLeaveDate(e.target.value)}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Reason for Absence (Optional)
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Annual medical symposium, family leave, clinical conference..."
              className="w-full p-3 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 leading-relaxed"
            />
          </div>

          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200/80 text-xs text-amber-900 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-bold">Clinic Policy Notice:</span>
              <p className="mt-0.5">
                Submitting leave for <strong className="text-amber-950">{leaveDate}</strong> will prevent patients from seeing any slots for that day. Any appointments already scheduled on that date will be immediately cancelled by the backend system.
              </p>
            </div>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2"
          >
            <CalendarOff className="w-4 h-4" /> Schedule Leave Day
          </button>
        </form>
      </div>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        title="Confirm Scheduled Leave"
        message={`Are you sure you want to mark ${leaveDate} as a leave day? Any patient appointments scheduled for this date will be cancelled by the clinic backend.`}
        confirmLabel="Yes, Schedule Leave"
        cancelLabel="Keep Working Day"
        variant="warning"
        isLoading={isSubmitting}
        onConfirm={handleApplyLeave}
        onCancel={() => setIsConfirmOpen(false)}
      />
    </div>
  );
};
