import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { doctorApi } from '../../api/doctor';
import type { Appointment } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import {
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Users,
  CalendarOff,
  Stethoscope,
  ArrowRight,
  User,
} from 'lucide-react';

export const DoctorDashboard: React.FC = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  const fetchAppointments = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await doctorApi.getMyAppointments();
      setAppointments(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load doctor appointments.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const handleConfirm = async (id: string) => {
    setActionLoadingId(id);
    setError(null);
    try {
      await doctorApi.confirmAppointment(id);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to confirm appointment.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (id: string) => {
    setActionLoadingId(id);
    setError(null);
    try {
      await doctorApi.rejectAppointment(id);
      await fetchAppointments();
    } catch (err: any) {
      setError(err.message || 'Failed to reject appointment.');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Calculations
  const todayStr = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter((a) => a.appointment_date === todayStr);
  const pendingAppointments = appointments.filter((a) => a.status === 'pending');
  const confirmedAppointments = appointments.filter((a) => a.status === 'confirmed');
  const completedAppointments = appointments.filter((a) => a.status === 'completed');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-slate-900 rounded-2xl text-white p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-semibold mb-3">
            <Stethoscope className="w-3.5 h-3.5" /> Specialist Clinical Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
            Dr. {user?.full_name}
          </h1>
          <p className="text-sm text-teal-100 leading-relaxed mb-6">
            Specialty: <strong className="text-white">{user?.specialty || 'General Physician'}</strong>. Review incoming patient requests, manage weekly consultation hours, and document private clinical visit notes.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/doctor/appointments"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs rounded-xl shadow-xs transition"
            >
              <Calendar className="w-4 h-4" /> Manage All Appointments ({appointments.length})
            </Link>
            <Link
              to="/doctor/availability"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-medium text-xs rounded-xl border border-white/20 transition"
            >
              <Clock className="w-4 h-4" /> Set Working Hours
            </Link>
          </div>
        </div>
      </div>

      {error && <ErrorMessage message={error} onRetry={fetchAppointments} onDismiss={() => setError(null)} />}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Pending Action</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{pendingAppointments.length}</div>
          <p className="text-[11px] text-amber-700 font-medium mt-1">Requires confirmation</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Today's Visits</span>
            <Calendar className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{todayAppointments.length}</div>
          <p className="text-[11px] text-teal-700 font-medium mt-1">Scheduled for today</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Confirmed</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{confirmedAppointments.length}</div>
          <p className="text-[11px] text-blue-700 font-medium mt-1">Upcoming consultations</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{completedAppointments.length}</div>
          <p className="text-[11px] text-emerald-700 font-medium mt-1">Visits with filed notes</p>
        </div>
      </div>

      {/* Pending Approval Priority Queue */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-500" /> Incoming Consultation Requests
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Patients awaiting confirmation for their requested 30-minute slots.
            </p>
          </div>
          <Link
            to="/doctor/appointments"
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
          >
            All Appointments <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <Loading message="Checking consultation requests..." />
        ) : pendingAppointments.length === 0 ? (
          <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500">
            No pending appointment requests waiting for review.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {pendingAppointments.slice(0, 5).map((app) => (
              <div
                key={app.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-sm text-slate-900">
                      {app.patient?.full_name || 'Registered Patient'}
                    </span>
                    <span className="text-xs text-slate-500">({app.patient?.phone || 'No phone'})</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-600">
                    <span className="flex items-center gap-1 font-medium">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {app.appointment_date}
                    </span>
                    <span className="flex items-center gap-1 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={actionLoadingId === app.id}
                    onClick={() => handleConfirm(app.id)}
                    className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition shadow-xs disabled:opacity-50 flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Confirm
                  </button>
                  <button
                    type="button"
                    disabled={actionLoadingId === app.id}
                    onClick={() => handleReject(app.id)}
                    className="px-3.5 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 font-semibold text-xs transition disabled:opacity-50 flex items-center gap-1"
                  >
                    <XCircle className="w-3.5 h-3.5" /> Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link
          to="/doctor/availability"
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 hover:shadow-sm transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900 mb-1">Set Working Hours</h3>
          <p className="text-xs text-slate-500">
            Define consultation windows (e.g. 09:00 - 17:00) by day of the week.
          </p>
        </Link>

        <Link
          to="/doctor/leaves"
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 hover:shadow-sm transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
            <CalendarOff className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900 mb-1">Schedule Leave Days</h3>
          <p className="text-xs text-slate-500">
            Mark off days and automatically cancel booked slots on that date.
          </p>
        </Link>

        <Link
          to="/doctor/patients"
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 hover:shadow-sm transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900 mb-1">Patient History</h3>
          <p className="text-xs text-slate-500">
            Look up confidential visit history and notes for your attending patients.
          </p>
        </Link>
      </div>
    </div>
  );
};
