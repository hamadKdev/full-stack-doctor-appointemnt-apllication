import React, { useState } from 'react';
import { doctorApi } from '../../api/doctor';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { Clock, CheckCircle2, Calendar, Info, Plus } from 'lucide-react';

const DAYS_OF_WEEK = [
  { index: 0, label: 'Monday' },
  { index: 1, label: 'Tuesday' },
  { index: 2, label: 'Wednesday' },
  { index: 3, label: 'Thursday' },
  { index: 4, label: 'Friday' },
  { index: 5, label: 'Saturday' },
  { index: 6, label: 'Sunday' },
];

export const DoctorAvailability: React.FC = () => {
  const [dayOfWeek, setDayOfWeek] = useState<number>(0);
  const [startTime, setStartTime] = useState<string>('09:00');
  const [endTime, setEndTime] = useState<string>('17:00');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (startTime >= endTime) {
      setError('Start time must precede end time.');
      return;
    }

    setIsSubmitting(true);
    try {
      await doctorApi.addAvailability({
        day_of_week: dayOfWeek,
        start_time: startTime,
        end_time: endTime,
      });

      const dayName = DAYS_OF_WEEK.find((d) => d.index === dayOfWeek)?.label;
      setSuccessMessage(
        `Availability saved! Weekly consultation hours set for ${dayName} from ${startTime} to ${endTime}. Patients can now book 30-minute slots in this window.`
      );
    } catch (err: any) {
      setError(err.message || 'Failed to update working hours.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const applyPreset = (start: string, end: string) => {
    setStartTime(start);
    setEndTime(end);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Doctor Working Availability
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Configure your weekly consultation schedule to generate bookable 30-minute appointment slots.
        </p>
      </div>

      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Day Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Day of Week
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
              {DAYS_OF_WEEK.map((day) => {
                const isSelected = dayOfWeek === day.index;
                return (
                  <button
                    key={day.index}
                    type="button"
                    onClick={() => setDayOfWeek(day.index)}
                    className={`py-3 px-2 rounded-xl text-xs font-semibold transition border text-center ${
                      isSelected
                        ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {day.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time pickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Shift Start Time
              </label>
              <div className="relative">
                <input
                  type="time"
                  required
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Shift End Time
              </label>
              <div className="relative">
                <input
                  type="time"
                  required
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Quick presets */}
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Common Shift Presets
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => applyPreset('09:00', '17:00')}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition"
              >
                Full Day (09:00 - 17:00)
              </button>
              <button
                type="button"
                onClick={() => applyPreset('08:30', '14:30')}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition"
              >
                Morning Shift (08:30 - 14:30)
              </button>
              <button
                type="button"
                onClick={() => applyPreset('14:00', '20:00')}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition"
              >
                Evening Shift (14:00 - 20:00)
              </button>
            </div>
          </div>

          {/* System rule note */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-3">
            <Info className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold text-slate-800">30-Minute Standard Slot Rule:</span>
              <p className="mt-0.5">
                The backend divides your configured hours into fixed 30-minute intervals (e.g. 09:00 - 09:30, 09:30 - 10:00). Patients will immediately see these slots available when booking on this day of the week.
              </p>
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow-xs transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              'Saving Schedule to Server...'
            ) : (
              <>
                <Plus className="w-4 h-4" /> Save Availability Schedule
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
