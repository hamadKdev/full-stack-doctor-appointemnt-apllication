import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { doctorApi } from '../../api/doctor';
import type { Appointment } from '../../types';
import { StatusBadge } from '../../components/StatusBadge';
import { Loading } from '../../components/Loading';
import { ErrorMessage } from '../../components/ErrorMessage';
import { Users, Search, Calendar, Clock, FileText, UserCheck, Stethoscope } from 'lucide-react';

export const DoctorPatients: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [patientIdInput, setPatientIdInput] = useState<string>(
    searchParams.get('patient_id') || ''
  );

  const [history, setHistory] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchedId, setSearchedId] = useState<string | null>(null);

  // If patient_id param exists on mount, fetch history
  useEffect(() => {
    const pId = searchParams.get('patient_id');
    if (pId) {
      setPatientIdInput(pId);
      loadHistory(pId);
    }
  }, [searchParams]);

  const loadHistory = async (pId: string) => {
    if (!pId.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const data = await doctorApi.getPatientHistory(pId.trim());
      setHistory(data || []);
      setSearchedId(pId.trim());
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve patient clinical records.');
      setHistory([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientIdInput.trim()) {
      setError('Please provide a patient UUID or ID.');
      return;
    }
    setSearchParams({ patient_id: patientIdInput.trim() });
    loadHistory(patientIdInput.trim());
  };

  const patientInfo = history[0]?.patient;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Patient Clinical History
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Review past visits, medical notes, and treatment histories for your attending clinic patients.
        </p>
      </div>

      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}

      {/* Patient Search Form */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={patientIdInput}
              onChange={(e) => setPatientIdInput(e.target.value)}
              placeholder="Search or enter Patient ID (e.g. UUID from appointment card)..."
              className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-xl text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow-xs transition disabled:opacity-50 flex items-center justify-center gap-1.5 shrink-0"
          >
            <Search className="w-3.5 h-3.5" /> Lookup Records
          </button>
        </form>
      </div>

      {/* Results */}
      {loading ? (
        <Loading message="Loading patient clinical records..." />
      ) : searchedId ? (
        <div className="space-y-6">
          {/* Patient Overview Card if found */}
          {patientInfo && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-lg">
                  {patientInfo.full_name?.charAt(0) || 'P'}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{patientInfo.full_name}</h3>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                    <span>Email: {patientInfo.email}</span>
                    {patientInfo.phone && <span>• Phone: {patientInfo.phone}</span>}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Total Consultations</span>
                <span className="text-xl font-bold text-teal-700">{history.length}</span>
              </div>
            </div>
          )}

          {history.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base">No Records Found</h3>
              <p className="text-xs text-slate-500 mt-1">
                No appointment or note history found for patient ID: <span className="font-mono">{searchedId}</span>.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-4 text-xs font-semibold text-slate-800">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-teal-600" />
                        {app.appointment_date}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-teal-600" />
                        {app.start_time.slice(0, 5)} - {app.end_time.slice(0, 5)}
                      </span>
                    </div>
                    <StatusBadge status={app.status} />
                  </div>

                  {/* Visit Notes / Diagnoses */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Attending Notes & Observations
                    </span>
                    {app.notes && app.notes.length > 0 ? (
                      app.notes.map((noteItem, idx) => (
                        <div
                          key={noteItem.id || idx}
                          className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-wrap"
                        >
                          {noteItem.note}
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic">
                        No clinical notes filed for this session.
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">Select a Patient</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Click "Medical History" next to any patient on your appointments tab, or paste a patient UUID above.
          </p>
        </div>
      )}
    </div>
  );
};
