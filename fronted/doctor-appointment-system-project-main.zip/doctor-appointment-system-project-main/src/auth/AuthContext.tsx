import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authApi, type LoginPayload, type SignupPayload } from '../api/auth';
import { getStoredToken, getStoredUser, clearStoredAuth, setOnUnauthorizedCallback } from '../api/api';
import type { User, SignupResponse } from '../types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (credentials: LoginPayload) => Promise<User>;
  signup: (data: SignupPayload) => Promise<SignupResponse>;
  logout: () => void;
  refreshUser: () => Promise<User | null>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => getStoredUser());
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const logout = useCallback(() => {
    authApi.logout();
    setUser(null);
    setToken(null);
  }, []);

  const refreshUser = useCallback(async (): Promise<User | null> => {
    const currentToken = getStoredToken();
    if (!currentToken) {
      setUser(null);
      setToken(null);
      setIsLoading(false);
      return null;
    }

    try {
      const freshUser = await authApi.getMe();
      setUser(freshUser);
      setToken(currentToken);
      return freshUser;
    } catch {
      logout();
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [logout]);

  useEffect(() => {
    setOnUnauthorizedCallback(() => {
      logout();
    });

    refreshUser();
  }, [logout, refreshUser]);

  const login = async (credentials: LoginPayload): Promise<User> => {
    const res = await authApi.login(credentials);
    setToken(res.access_token);
    setUser(res.user);
    // Optionally fetch full profile
    try {
      const fresh = await authApi.getMe();
      setUser(fresh);
      return fresh;
    } catch {
      return res.user;
    }
  };

  const signup = async (data: SignupPayload): Promise<SignupResponse> => {
    return authApi.signup(data);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        login,
        signup,
        logout,
        refreshUser,
        isAuthenticated: !!token && !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
