export type UserRole = 'patient' | 'doctor' | 'admin';

export type AppointmentStatus =
  | 'pending'
  | 'confirmed'
  | 'rejected'
  | 'cancelled'
  | 'completed'
  | 'no-show'
  | 'no_show';

export interface User {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  role: UserRole;
  specialty?: string | null;
  is_active?: boolean;
  created_at?: string;
}

export interface Doctor {
  id: string;
  full_name: string;
  email?: string;
  phone?: string;
  specialty: string;
  is_active?: boolean;
}

export interface AppointmentSlot {
  start_time: string;
  end_time: string;
}

export interface Appointment {
  id: string;
  patient_id: string;
  doctor_id: string;
  appointment_date: string;
  start_time: string;
  end_time: string;
  status: AppointmentStatus;
  created_at: string;
  updated_at?: string;
  doctor?: {
    id: string;
    full_name: string;
    specialty?: string;
    email?: string;
    phone?: string;
  };
  patient?: {
    id: string;
    full_name: string;
    email: string;
    phone?: string;
  };
  visit_notes?: string | null | Array<{ id: string; note: string; created_at: string }>;
}

export interface VisitNoteItem {
  id?: string;
  appointment_id?: string;
  note: string;
  created_at?: string;
}

export interface AvailabilityItem {
  id?: string;
  doctor_id?: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  created_at?: string;
}

export interface DoctorLeaveItem {
  id?: string;
  doctor_id?: string;
  leave_date: string;
  reason?: string | null;
  created_at?: string;
}

export interface DoctorDashboardCounts {
  pending: number;
  confirmed: number;
  completed: number;
  no_show: number;
  cancelled: number;
  rejected: number;
}

export interface DoctorStatSummary {
  doctor: {
    id: string;
    full_name: string;
    specialty: string;
  };
  counts: DoctorDashboardCounts;
}

export interface AdminDashboardData {
  today: string;
  today_appointments: Appointment[];
  doctors: DoctorStatSummary[];
}

export interface LoginResponse {
  message: string;
  access_token: string;
  token_type: string;
  user: User;
}

export interface SignupResponse {
  message: string;
  user: User;
}

export interface CreateDoctorResponse {
  message: string;
  doctor_id: string;
  temporary_password?: string;
}
