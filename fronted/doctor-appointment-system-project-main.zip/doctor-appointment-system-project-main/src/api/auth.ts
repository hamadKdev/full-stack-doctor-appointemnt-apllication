import { apiClient, setStoredToken, setStoredUser, clearStoredAuth } from './api';
import type { LoginResponse, SignupResponse, User } from '../types';

export interface SignupPayload {
  full_name: string;
  email: string;
  phone: string;
  password: string;
}

export interface LoginPayload {
  email: string;
  password: string;
}

export const authApi = {
  async signup(data: SignupPayload): Promise<SignupResponse> {
    return apiClient<SignupResponse>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async login(credentials: LoginPayload): Promise<LoginResponse> {
    const response = await apiClient<LoginResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });

    if (response.access_token) {
      setStoredToken(response.access_token);
      if (response.user) {
        setStoredUser(response.user);
      }
    }
    return response;
  },

  async getMe(): Promise<User> {
    const user = await apiClient<User>('/auth/me', {
      method: 'GET',
    });
    setStoredUser(user);
    return user;
  },

  logout(): void {
    clearStoredAuth();
  },

  // Admin bootstrap helper (internal tool)
  async bootstrapAdmin(data: SignupPayload, secret?: string): Promise<{ message: string; user_id: string }> {
    const headers: Record<string, string> = {};
    if (secret) {
      headers['x-admin-bootstrap-secret'] = secret;
    }
    return apiClient('/auth/bootstrap-admin', {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });
  },
};
