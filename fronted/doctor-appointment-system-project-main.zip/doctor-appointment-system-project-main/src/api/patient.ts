import { apiClient } from './api';
import type { Doctor, Appointment, AppointmentSlot, VisitNoteItem } from '../types';

export interface BookAppointmentPayload {
  doctor_id: string;
  appointment_date: string;
  start_time: string;
}

export interface ReschedulePayload {
  appointment_date: string;
  start_time: string;
}

export const patientApi = {
  // Get active doctors available for booking
  async getDoctors(): Promise<Doctor[]> {
    return apiClient<Doctor[]>('/doctors', {
      method: 'GET',
    });
  },

  // Get available 30-min slots for a doctor on a specific date
  async getDoctorSlots(doctorId: string, appointmentDate: string): Promise<AppointmentSlot[]> {
    return apiClient<AppointmentSlot[]>(
      `/doctors/${doctorId}/slots?appointment_date=${encodeURIComponent(appointmentDate)}`,
      {
        method: 'GET',
      }
    );
  },

  // Book an appointment (created as pending)
  async bookAppointment(payload: BookAppointmentPayload): Promise<{ message: string; appointment: Appointment }> {
    return apiClient<{ message: string; appointment: Appointment }>('/appointments', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Get current patient's appointments
  async getMyAppointments(): Promise<Appointment[]> {
    return apiClient<Appointment[]>('/patient/appointments', {
      method: 'GET',
    });
  },

  // Cancel an appointment (at least 2 hours before)
  async cancelAppointment(appointmentId: string): Promise<{ message: string }> {
    return apiClient<{ message: string }>(`/appointments/${appointmentId}/cancel`, {
      method: 'PATCH',
    });
  },

  // Reschedule an appointment (at least 2 hours before)
  async rescheduleAppointment(
    appointmentId: string,
    payload: ReschedulePayload
  ): Promise<{ message: string; appointment: Appointment }> {
    return apiClient<{ message: string; appointment: Appointment }>(
      `/appointments/${appointmentId}/reschedule`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    );
  },

  // Get private visit notes for a specific appointment
  async getAppointmentNote(appointmentId: string): Promise<VisitNoteItem[]> {
    const res = await apiClient<any>(`/patient/appointments/${appointmentId}/note`, {
      method: 'GET',
    });
    if (Array.isArray(res)) return res;
    if (res && res.note) return [res];
    return [];
  },
};
