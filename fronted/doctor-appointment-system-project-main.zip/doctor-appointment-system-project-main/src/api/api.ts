export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  'https://doctor-apointemt-managemnt-system-2.vercel.app';

export class ApiError extends Error {
  status: number;
  data: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

// Token storage key
const TOKEN_KEY = 'nfc_auth_token';
const USER_KEY = 'nfc_auth_user';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredAuth(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): any | null {
  try {
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setStoredUser(user: any): void {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

let onUnauthorizedCallback: (() => void) | null = null;

export function setOnUnauthorizedCallback(cb: () => void) {
  onUnauthorizedCallback = cb;
}

export async function apiClient<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL.replace(/\/$/, '')}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;

  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const token = getStoredToken();
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (response.status === 401) {
      clearStoredAuth();
      if (onUnauthorizedCallback) {
        onUnauthorizedCallback();
      }
      throw new ApiError('Your session has expired. Please login again.', 401);
    }

    if (response.status === 403) {
      let message = 'You do not have permission to perform this action.';
      try {
        const errorJson = await response.json();
        if (errorJson?.detail && typeof errorJson.detail === 'string') {
          message = errorJson.detail;
        }
      } catch {}
      throw new ApiError(message, 403);
    }

    if (response.status === 409) {
      let message = 'This appointment slot is no longer available. Please select another slot.';
      try {
        const errorJson = await response.json();
        if (errorJson?.detail && typeof errorJson.detail === 'string') {
          message = errorJson.detail;
        }
      } catch {}
      throw new ApiError(message, 409);
    }

    // Attempt to parse JSON
    let data: any = null;
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      try {
        data = await response.json();
      } catch {
        data = null;
      }
    } else {
      const text = await response.text();
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
    }

    if (!response.ok) {
      let errorMessage = `Request failed with status ${response.status}`;
      if (data && data.detail) {
        if (typeof data.detail === 'string') {
          errorMessage = data.detail;
        } else if (Array.isArray(data.detail)) {
          errorMessage = data.detail
            .map((err: any) => err.msg || `${err.loc?.join('.')}: ${err.msg}`)
            .join(', ');
        }
      } else if (data && data.message) {
        errorMessage = data.message;
      }
      throw new ApiError(errorMessage, response.status, data);
    }

    return data as T;
  } catch (error: any) {
    if (error instanceof ApiError) {
      throw error;
    }
    // Network errors, CORS, etc.
    throw new ApiError(
      error.message || 'Unable to connect to the clinic server. Please check your network connection.',
      0
    );
  }
}
