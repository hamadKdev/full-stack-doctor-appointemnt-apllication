import { apiClient } from './api';
import type { Appointment, AvailabilityItem, DoctorLeaveItem } from '../types';

export interface DoctorAvailabilityPayload {
  day_of_week: number; // 0=Monday, 6=Sunday
  start_time: string;  // "09:00"
  end_time: string;    // "17:00"
}

export interface DoctorLeavePayload {
  leave_date: string; // "YYYY-MM-DD"
  reason?: string | null;
}

export interface FinishVisitPayload {
  note: string;
}

export const doctorApi = {
  // Get doctor's own appointments
  async getMyAppointments(): Promise<Appointment[]> {
    return apiClient<Appointment[]>('/doctor/appointments', {
      method: 'GET',
    });
  },

  // Confirm pending appointment
  async confirmAppointment(appointmentId: string): Promise<{ message: string }> {
    return apiClient<{ message: string }>(`/doctor/appointments/${appointmentId}/confirm`, {
      method: 'PATCH',
    });
  },

  // Reject pending appointment
  async rejectAppointment(appointmentId: string): Promise<{ message: string }> {
    return apiClient<{ message: string }>(`/doctor/appointments/${appointmentId}/reject`, {
      method: 'PATCH',
    });
  },

  // Finish visit (status: 'completed' | 'no-show' or 'no_show') with visit note
  async finishVisit(
    appointmentId: string,
    status: 'completed' | 'no-show' | 'no_show',
    note: string
  ): Promise<{ message: string }> {
    const statusParam = status === 'no_show' ? 'no-show' : status;
    return apiClient<{ message: string }>(
      `/doctor/appointments/${appointmentId}/finish?status=${encodeURIComponent(statusParam)}`,
      {
        method: 'PATCH',
        body: JSON.stringify({ note }),
      }
    );
  },

  // Set/add weekly availability slot
  async addAvailability(payload: DoctorAvailabilityPayload): Promise<AvailabilityItem> {
    return apiClient<AvailabilityItem>('/doctor/availability', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Add a leave day
  async addLeave(payload: DoctorLeavePayload): Promise<{ message: string; cancelled?: number }> {
    return apiClient<{ message: string; cancelled?: number }>('/doctor/leave', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Get a specific patient's visit history (only allowed for attending doctor)
  async getPatientHistory(patientId: string): Promise<Appointment[]> {
    return apiClient<Appointment[]>(`/doctor/patients/${patientId}/history`, {
      method: 'GET',
    });
  },
};
