import React from 'react';
import type { AppointmentStatus } from '../types';

interface StatusBadgeProps {
  status: AppointmentStatus | string;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  const normalized = (status || '').toLowerCase().replace('_', '-');

  let badgeClasses = 'bg-slate-100 text-slate-700 border-slate-200';
  let dotClasses = 'bg-slate-400';
  let label = status;

  switch (normalized) {
    case 'pending':
      badgeClasses = 'bg-amber-50 text-amber-800 border-amber-200/80';
      dotClasses = 'bg-amber-500';
      label = 'Pending';
      break;
    case 'confirmed':
      badgeClasses = 'bg-blue-50 text-blue-800 border-blue-200/80';
      dotClasses = 'bg-blue-600';
      label = 'Confirmed';
      break;
    case 'completed':
      badgeClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200/80';
      dotClasses = 'bg-emerald-600';
      label = 'Completed';
      break;
    case 'no-show':
      badgeClasses = 'bg-purple-50 text-purple-800 border-purple-200/80';
      dotClasses = 'bg-purple-600';
      label = 'No-show';
      break;
    case 'rejected':
      badgeClasses = 'bg-rose-50 text-rose-800 border-rose-200/80';
      dotClasses = 'bg-rose-600';
      label = 'Rejected';
      break;
    case 'cancelled':
      badgeClasses = 'bg-zinc-100 text-zinc-700 border-zinc-200';
      dotClasses = 'bg-zinc-400';
      label = 'Cancelled';
      break;
    default:
      label = status;
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${badgeClasses} ${className}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotClasses}`} />
      <span className="capitalize">{label}</span>
    </span>
  );
};
