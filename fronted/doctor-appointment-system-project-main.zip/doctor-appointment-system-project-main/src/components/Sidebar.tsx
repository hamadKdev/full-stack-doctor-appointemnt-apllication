import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import {
  LayoutDashboard,
  CalendarPlus,
  Calendar,
  Clock,
  CalendarOff,
  FileText,
  Users,
  Stethoscope,
  Shield,
  User,
  HeartPulse,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  if (!user) return null;

  const patientLinks = [
    { to: '/patient/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/patient/book', label: 'Book Appointment', icon: CalendarPlus },
    { to: '/patient/appointments', label: 'My Appointments', icon: Calendar },
    { to: '/patient/history', label: 'Visit History', icon: FileText },
    { to: '/patient/profile', label: 'Profile', icon: User },
  ];

  const doctorLinks = [
    { to: '/doctor/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/doctor/appointments', label: 'Appointments', icon: Calendar },
    { to: '/doctor/availability', label: 'Availability', icon: Clock },
    { to: '/doctor/leaves', label: 'Leave Days', icon: CalendarOff },
    { to: '/doctor/patients', label: 'Patient History', icon: Users },
    { to: '/doctor/profile', label: 'Profile', icon: Stethoscope },
  ];

  const adminLinks = [
    { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/admin/doctors', label: 'Doctor Management', icon: Stethoscope },
    { to: '/admin/patients', label: 'Patient Management', icon: Users },
    { to: '/admin/appointments', label: 'Appointments', icon: Calendar },
    { to: '/admin/profile', label: 'Profile', icon: Shield },
  ];

  const links =
    user.role === 'admin'
      ? adminLinks
      : user.role === 'doctor'
      ? doctorLinks
      : patientLinks;

  const roleTitle =
    user.role === 'admin'
      ? 'Admin Console'
      : user.role === 'doctor'
      ? 'Doctor Portal'
      : 'Patient Portal';

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs md:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-slate-50 border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-teal-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              {roleTitle}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5 truncate">
            {user.role === 'doctor' && user.specialty ? user.specialty : user.email}
          </p>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {links.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                    isActive
                      ? 'bg-teal-600 text-white shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 bg-slate-100/50 text-xs text-slate-500">
          <div className="flex items-center justify-between">
            <span>Clinic Time</span>
            <span className="font-semibold text-slate-700">09:00 - 17:00</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">Slots: 30-min standard</p>
        </div>
      </aside>
    </>
  );
};
